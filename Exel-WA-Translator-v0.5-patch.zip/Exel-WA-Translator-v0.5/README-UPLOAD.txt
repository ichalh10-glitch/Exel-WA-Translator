EXEL WA TRANSLATOR v0.5 - PATCH

Upload two files to the EXISTING GitHub repository using GitHub web UI:
1. app/src/main/java/com/exel/watranslator/MainActivity.java
2. app/build.gradle

For each file, open its existing path in GitHub, select Edit (pencil), replace entire content with corresponding file in this ZIP, and commit changes.
GitHub Actions should build the APK if configured for push events.

Improvements: allow model download over cellular, 30-second status/retry UI, async Pinyin processing, request-id protection, improved errors, version bump.
Limitations: first model download can still take longer than 30 seconds; this is a UI warning, not cancellation. This patch has not been compiled or device-tested here.
