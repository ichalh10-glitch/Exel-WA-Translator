Upload folder mipmap-* ke app/src/main/res/.
Pastikan tag <application> di AndroidManifest.xml berisi:
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher_round"
Setelah commit, jalankan/build GitHub Actions kembali.